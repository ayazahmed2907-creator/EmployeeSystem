# What changed, and what you still need to do

## 1) Security issue found and fixed
Your old `api/db-connect.php` had the real database host, username, and
password typed directly into the file — and it echoed the raw MySQL error
back to any visitor if the connection failed. Since that file was in the zip
you shared, **please change that database password in your InfinityFree
panel now** and treat the old one as compromised.

`db-connect.php` now reads the connection details from environment
variables instead, so credentials never live in a file again:
- `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`
- On InfinityFree's free plan you generally can't set real environment
  variables from the control panel. Two options:
  1. Ask their support / check your plan for an "Environment Variables" or
     ".htaccess SetEnv" option, or
  2. If that's not available, create a `db-secrets.php` file **outside**
     any folder you'd ever zip and share again, `define()` the four values
     there, and `require` it at the top of `db-connect.php` instead of the
     `getenv()` calls. Send me the new values once you have them and I'll
     write that file for you — either way, never put real credentials in a
     file you might upload, paste, or send to anyone (including me) again.

`api/mysqli.php` was deleted — it was old test code that tried to
`CREATE DATABASE` on every request and wasn't used anywhere.

## 2) Run the database migration
Open phpMyAdmin for your database → SQL tab → paste the contents of
`api/migration.sql` → Go.

**This deletes every employee currently in your `employees` table** (you
asked for the old shared data to go away, not be migrated), then adds the
`users` (accounts) table and an `owner_user_id` column so every employee
row belongs to exactly one account from now on. If you want a backup
first, export the `employees` table from phpMyAdmin before running it.

Also delete any files sitting in `api/uploads/` on your server from
before this update — they belonged to the old shared system and are now
orphaned.

## 3) How the login system works now
- **A brand-new visitor** sees only a sign-in screen — there is no way to
  reach the employee system without an account.
- **Registering** (email + password, or "Sign in with Google" the first
  time) creates a new, empty account. It starts with **zero employees** —
  nothing from anyone else is visible.
- **Signing in** only succeeds with a real, already-registered account —
  either the email/password matches exactly, or it's a Google account
  that's signed in before.
- Once signed in, every employee you add, every photo you upload, and
  every export only ever shows *that* account's data. This is enforced on
  the server (every database query and every photo request is scoped to
  the signed-in account's id), not just hidden in the interface — so it
  can't be bypassed by editing the page.
- Photos are stored in a separate folder per account
  (`api/uploads/<your account id>/…`), and that folder can no longer be
  browsed directly — every photo now goes through `api/photo.php`, which
  checks you actually own it before sending it back. Two accounts can
  never see each other's photos, even by guessing a file name.

Note: registering only checks that the email address is *formatted*
correctly (has an `@`, a domain, etc.) — it doesn't verify that the
address is real or that the person owns it. Doing that would need a
confirmation email, which needs a mail-sending service (Gmail SMTP,
SendGrid, etc.) that isn't set up. Say the word if you want that added.

## 4) Turn on "Sign in with Google" (optional — email+password works immediately)
1. Go to https://console.cloud.google.com/apis/credentials
2. Create a project (or use an existing one) → **Create Credentials** →
   **OAuth client ID** → Application type **Web application**.
3. Under **Authorized JavaScript origins**, add your site's URL (e.g.
   `https://yoursite.infinityfreeapp.com`).
4. Copy the **Client ID** it gives you (ends in
   `.apps.googleusercontent.com`).
5. Paste it in **two places**:
   - `api/auth-common.php` → the `GOOGLE_CLIENT_ID` constant near the top.
   - `script.js` → the `GOOGLE_CLIENT_ID` constant near the top.

Until you do this, the Google button is automatically replaced with a
plain button explaining it isn't set up yet — email + password works the
whole time regardless.

**Heads-up for InfinityFree specifically:** the free tier sometimes blocks
outbound requests from PHP to other servers, which `auth-google.php` uses
to verify a Google sign-in. If it fails with "could not reach Google"
after you've added the Client ID, that's why — email + password is
unaffected.

## 5) Photos — the bug, and the fix
Every uploaded photo was saved on the server under `api/uploads/…`, but
the app's pages live at the site root, and the code was pointing the
`<img>` tags straight at `uploads/…` (missing the `api/` part) — so the
browser looked in the wrong place and the photo silently never appeared,
in the records list, in search results, and in the edit screen. This is
fixed now, and photos also route through the new `api/photo.php`
auth-check described above.

## 6) File map
- `api/auth-common.php` — session handling + the `GOOGLE_CLIENT_ID` setting
- `api/auth-register.php`, `auth-login.php`, `auth-logout.php`,
  `auth-session.php` — email/password account creation, sign-in, sign-out,
  "am I signed in?" check
- `api/auth-google.php` — verifies Google's sign-in token and signs the
  person in
- `api/photo.php` — the only way a photo is ever served; checks ownership first
- `api/uploads/.htaccess` — blocks direct/raw access to the uploads folder
- `api/query.php`, `register-employee.php`, `update-employee.php`,
  `delete-employee.php` — require sign-in; every query is scoped to the
  signed-in account; photos are saved into that account's own subfolder
- `api/employee-validation.php` — photo upload now takes the account id
  and saves into `uploads/<accountId>/`
- `api/migration.sql` — one-time database change (see step 2)
- `index.html` / `style.css` / `script.js` — sign-in screen, account name +
  sign-out button, mobile hamburger menu, broader mobile layout pass,
  fixed photo URLs, and photos now appear on each employee's PDF page

## Still worth deciding
- Real email verification (confirmation link) before an account can be
  used — needs a mail-sending service, not built yet.
- Password reset ("forgot password") — same requirement, not built yet.
- Whether one account should ever be able to invite teammates into the
  *same* company space — right now it's strictly one space per login, as
  you asked for.
