<?php
/* ============================================================
   db-secrets.php
   Fill in your four real InfinityFree MySQL values below between
   the quotes, then upload this file into your api/ folder (same
   place as db-connect.php).

   Never zip this file up or paste its contents anywhere —
   including back to me.
   ============================================================ */

return [
    'host'     => 'sql308.infinityfree.com',   // e.g. sql308.infinityfree.com
    'user'     => 'if0_42743539',   // e.g. if0_42743539
    'password' => 'Somnan2907',   // your database password
    'name'     => 'if0_42743539_employeesystem',   // e.g. if0_42743539_employeesystem
];

