<?php
/* ============================================================
   photo.php
   Serves one employee's photo — but only to the account that
   owns it. The uploads/ folder itself is blocked from direct
   access (see uploads/.htaccess), so this is the only way any
   photo ever reaches a browser.

     GET photo.php?path=uploads/<ownerId>/<filename>
   ============================================================ */

require __DIR__ . '/auth-common.php';
$ownerId = requireAuth();

$path = (string) ($_GET['path'] ?? '');

// Must look exactly like "uploads/<numeric owner id>/<safe filename>",
// and that numeric owner id must match whoever is signed in right now —
// this is what actually stops one account from viewing another's photos.
if (!preg_match('#^uploads/(\d+)/([a-f0-9]+\.(?:png|jpe?g))$#', $path, $m)) {
    http_response_code(400);
    exit('Invalid photo path.');
}
$fileOwnerId = (int) $m[1];
$filename    = $m[2];

if ($fileOwnerId !== $ownerId) {
    http_response_code(403);
    exit('Not your photo.');
}

$fullPath = __DIR__ . '/uploads/' . $fileOwnerId . '/' . $filename;
if (!is_file($fullPath)) {
    http_response_code(404);
    exit('Photo not found.');
}

$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mime = ($ext === 'png') ? 'image/png' : 'image/jpeg';

header('Content-Type: ' . $mime);
header('Cache-Control: private, max-age=3600');
readfile($fullPath);
