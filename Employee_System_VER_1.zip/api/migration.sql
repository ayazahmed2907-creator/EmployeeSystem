-- ============================================================
-- migration.sql
-- Your database ALREADY has an `employees` table from before
-- (the old, shared, no-login version). This drops it and both
-- tables are created fresh, set up so every account's employees
-- are kept separate from the start.
--
-- This DELETES every employee currently in your `employees`
-- table — that's intentional (you asked for the old shared test
-- data to go away, not be migrated). Export the `employees`
-- table from phpMyAdmin first if you want a backup.
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(150) NOT NULL,
    email         VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NULL,          -- NULL for Google-only accounts
    google_id     VARCHAR(64)  NULL,          -- Google's stable "sub" id
    company_name  VARCHAR(150) NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_users_email (email),
    UNIQUE KEY uniq_users_google_id (google_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    owner_user_id    INT NOT NULL,
    reg_no           VARCHAR(20) NOT NULL,
    reference_no     VARCHAR(30) NOT NULL,
    full_name        VARCHAR(150) NOT NULL,
    email            VARCHAR(150) NOT NULL,
    phone            VARCHAR(30) NOT NULL,
    department       VARCHAR(100) NOT NULL,
    employment_type  VARCHAR(50) NULL,
    office_location  VARCHAR(100) NULL,
    job_title        VARCHAR(150) NULL,
    salary           DECIMAL(12,2) NULL,
    is_confidential  TINYINT(1) NOT NULL DEFAULT 0,
    start_date       DATE NULL,
    skills           TEXT NULL,
    photo_path       VARCHAR(255) NULL,
    filed_at         DATETIME NOT NULL,
    updated_at       DATETIME NULL,
    UNIQUE KEY uniq_owner_reg_no (owner_user_id, reg_no),
    UNIQUE KEY uniq_owner_reference_no (owner_user_id, reference_no),
    UNIQUE KEY uniq_owner_email (owner_user_id, email),
    CONSTRAINT fk_employees_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
