<?php
/* ============================================================
   auth-login.php
     POST auth-login.php   body: { email, password }
   ============================================================ */

require __DIR__ . '/auth-common.php';
require __DIR__ . '/db-connect.php';
$conn = getDbConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonFail('Only POST is accepted.', 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    jsonFail('Invalid JSON payload.');
}

$email    = trim((string) ($data['email'] ?? ''));
$password = (string) ($data['password'] ?? '');

if ($email === '' || $password === '') {
    jsonFail('Enter your email and password.');
}

$stmt = $conn->prepare('SELECT id, name, email, password_hash FROM users WHERE email = ? LIMIT 1');
if (!$stmt) {
    error_log('Login prepare failed: ' . $conn->error);
    jsonFail('Could not sign in right now.', 500);
}
$stmt->bind_param('s', $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if (!$user || !$user['password_hash'] || !password_verify($password, $user['password_hash'])) {
    jsonFail('Incorrect email or password.', 401);
}

startSessionFor($user);

echo json_encode(['status' => 'ok', 'user' => ['id' => (int) $user['id'], 'name' => $user['name'], 'email' => $user['email']]]);
