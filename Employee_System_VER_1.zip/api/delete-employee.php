<?php
/* ============================================================
   delete-employee.php
   Deletes one employee dossier, called from script.js's
   deleteEmployeeBtn handler when editing a record.

     POST delete-employee.php   body: { "ref": "ERP-2026-00101" }

   The row is located by reference_no, same as update-employee.php.
   If the record has a photo on disk, that file is removed too —
   otherwise every deleted dossier leaves an orphaned upload behind.
   ============================================================ */

require __DIR__ . '/auth-common.php';
require __DIR__ . '/db-connect.php';
require __DIR__ . '/employee-validation.php';
$ownerId = requireAuth();
$conn = getDbConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Only POST is accepted.']);
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload.']);
    exit;
}

/* ---------- which record are we deleting? ---------- */
$referenceNo = cleanText($data['ref'] ?? '', 30);
if ($referenceNo === '') {
    fail('Missing ref — cannot tell which employee to delete.');
}

/* ---------- confirm it exists, and grab its photo path so we can clean up the file ---------- */
$lookup = $conn->prepare('SELECT id, photo_path FROM employees WHERE reference_no = ? AND owner_user_id = ? LIMIT 1');
if (!$lookup) {
    error_log('Delete lookup prepare failed: ' . $conn->error);
    fail('Could not delete the employee record.', 500);
}
$lookup->bind_param('si', $referenceNo, $ownerId);
$lookup->execute();
$existing = $lookup->get_result()->fetch_assoc();
$lookup->close();

if (!$existing) {
    fail('No employee found with that reference number.', 404);
}

/* ---------- delete the row with a prepared statement ---------- */
$stmt = $conn->prepare('DELETE FROM employees WHERE reference_no = ? AND owner_user_id = ?');
$stmt->bind_param('si', $referenceNo, $ownerId);

if (!$stmt->execute()) {
    error_log('Delete failed: ' . $stmt->error);
    fail('Could not delete the employee record.', 500);
}

// Only remove the photo file once the DB row is actually gone.
if (!empty($existing['photo_path'])) {
    $photoFile = __DIR__ . '/' . $existing['photo_path'];
    if (is_file($photoFile)) {
        @unlink($photoFile);
    }
}

echo json_encode(['status' => 'ok', 'ref' => $referenceNo]);

$stmt->close();
$conn->close();
