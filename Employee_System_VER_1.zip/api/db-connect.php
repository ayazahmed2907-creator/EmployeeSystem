<?php
/* ============================================================
   db-connect.php
   Opens (once per request) the MySQL connection every endpoint
   uses. Credentials come from api/db-secrets.php — a plain PHP
   array, not environment variables — so this works even on
   hosting plans where putenv()/getenv() are blocked.

   Upload db-secrets.php into this same api/ folder with your
   real values filled in. Never zip it up or share its contents.
   ============================================================ */

mysqli_report(MYSQLI_REPORT_OFF);

function getDbConnection(): mysqli {
    static $conn = null;
    if ($conn !== null) {
        return $conn;
    }

    $secretsFile = __DIR__ . '/db-secrets.php';

    if (!is_file($secretsFile)) {
        error_log('DB connection failed: db-secrets.php not found at ' . $secretsFile);
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Database is not configured on this server yet.',
        ]);
        exit;
    }

    $secrets  = require $secretsFile;
    $host     = trim((string) ($secrets['host']     ?? ''));
    $user     = trim((string) ($secrets['user']     ?? ''));
    $password = (string) ($secrets['password'] ?? '');
    $dbname   = trim((string) ($secrets['name']     ?? ''));

    if ($host === '' || $user === '' || $dbname === '') {
        error_log('DB connection failed: host, user, or name is still blank in db-secrets.php.');
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Database is not configured on this server yet.',
        ]);
        exit;
    }

    $conn = mysqli_connect($host, $user, $password, $dbname);

    if (!$conn) {
        error_log('DB connection failed: ' . mysqli_connect_error());
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Database connection failed. Check server error log for details.',
        ]);
        exit;
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}
