<?php
/* ============================================================
   auth-common.php
   Session bootstrap + helpers shared by every auth-*.php file
   and by every employee-data endpoint (query.php,
   register-employee.php, update-employee.php,
   delete-employee.php). Include this BEFORE db-connect.php.

   >>> Set GOOGLE_CLIENT_ID below once you've created one in the
       Google Cloud Console (see README-LOGIN.md). Until then the
       "Sign in with Google" button will show a clear error;
       email + password login/registration works right away. <<<
   ============================================================ */

define('GOOGLE_CLIENT_ID', '382586540736-aottrcgscu29khocvj9c94ar21mhjap3.apps.googleusercontent.com');

/* Detect HTTPS reliably, including when InfinityFree/Cloudflare terminate
   SSL in front of the app and PHP only sees a plain HTTP request internally
   (in that case $_SERVER['HTTPS'] is empty even though the visitor really is
   on https://). Without this, the session cookie below could get marked
   Secure while being set over what PHP *thinks* is HTTP, and browsers then
   silently refuse to store it — this is a common cause of "login works,
   then every next request looks signed out" on shared hosts, and it tends
   to bite phones first because mobile browsers enforce cookie rules more
   strictly than desktop ones. */
function isRequestSecure(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return true;
    }
    if (!empty($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) {
        return true;
    }
    return false;
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => isRequestSecure(),
    ]);
    session_start();
}

header('Content-Type: application/json');

function jsonFail($message, $code = 400) {
    http_response_code($code);
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit;
}

/* Every employee-data endpoint calls this first. Returns the
   logged-in user's id, or stops the request with 401. */
function requireAuth(): int {
    if (empty($_SESSION['user_id'])) {
        jsonFail('Please sign in to continue.', 401);
    }
    return (int) $_SESSION['user_id'];
}

function currentUser(): ?array {
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    return [
        'id'    => (int) $_SESSION['user_id'],
        'name'  => $_SESSION['user_name']  ?? '',
        'email' => $_SESSION['user_email'] ?? '',
    ];
}

function startSessionFor(array $user): void {
    session_regenerate_id(true); // prevent session fixation on login/register
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
}
