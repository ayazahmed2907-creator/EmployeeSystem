<?php
/* ============================================================
   db-connect.php
   Opens (once per request) the MySQL connection every endpoint
   uses. Credentials come from environment variables so they are
   never sitting in a file that could be zipped up and shared —
   set them in your hosting control panel (see README-LOGIN.md).
   A local fallback is kept only for quick local testing.
   ============================================================ */

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function getDbConnection(): mysqli {
    static $conn = null;
    if ($conn !== null) {
        return $conn;
    }

    $host     = getenv('DB_HOST')     ?: 'localhost';
    $user     = getenv('DB_USER')     ?: 'root';
    $password = getenv('DB_PASSWORD') ?: '';
    $dbname   = getenv('DB_NAME')     ?: 'employeesystem';

    try {
        $conn = new mysqli($host, $user, $password, $dbname);
        $conn->set_charset('utf8mb4');
    } catch (mysqli_sql_exception $e) {
        error_log('DB connection failed: ' . $e->getMessage());
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Database connection failed. Check server error log for details.',
        ]);
        exit;
    }

    return $conn;
}
