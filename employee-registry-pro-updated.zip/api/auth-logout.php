<?php
require __DIR__ . '/auth-common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonFail('Only POST is accepted.', 405);
}

$_SESSION = [];
session_destroy();

echo json_encode(['status' => 'ok']);
