-- ============================================================
-- migration.sql
-- Run this once against your existing database (phpMyAdmin ->
-- your DB -> SQL tab -> paste and Go). It adds accounts/login
-- and makes every employee belong to one account, so different
-- companies never see each other's data.
-- ============================================================

-- 1) Accounts table. One row per signed-in company/user.
CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(150) NOT NULL,
    email         VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NULL,          -- NULL for Google-only accounts
    google_id     VARCHAR(64)  NULL,          -- Google's stable "sub" id, when signed in with Google
    company_name  VARCHAR(150) NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_users_email (email),
    UNIQUE KEY uniq_users_google_id (google_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) Give every existing employee row an owner. If you already have
--    employees in the table from before, this creates one fallback
--    account and assigns all of them to it so nothing is lost.
INSERT INTO users (name, email, password_hash, company_name)
SELECT 'Legacy data', 'legacy@local', NULL, 'Unassigned'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'legacy@local');

ALTER TABLE employees
    ADD COLUMN IF NOT EXISTS owner_user_id INT NOT NULL DEFAULT 0 AFTER id;

UPDATE employees
   SET owner_user_id = (SELECT id FROM users WHERE email = 'legacy@local')
 WHERE owner_user_id = 0;

-- 3) reg_no / reference_no / email used to be globally unique. That's
--    wrong once there are multiple accounts (two different companies
--    could both want "REG-000101"), so uniqueness now only applies
--    *within* one account.
ALTER TABLE employees DROP INDEX IF EXISTS reg_no;
ALTER TABLE employees DROP INDEX IF EXISTS reference_no;
ALTER TABLE employees DROP INDEX IF EXISTS email;

ALTER TABLE employees
    ADD UNIQUE KEY uniq_owner_reg_no (owner_user_id, reg_no),
    ADD UNIQUE KEY uniq_owner_reference_no (owner_user_id, reference_no),
    ADD UNIQUE KEY uniq_owner_email (owner_user_id, email),
    ADD CONSTRAINT fk_employees_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE;
