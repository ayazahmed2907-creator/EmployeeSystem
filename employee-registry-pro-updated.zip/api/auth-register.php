<?php
/* ============================================================
   auth-register.php
   Creates a brand-new account (a new, isolated company space).

     POST auth-register.php   body: { name, email, password }
   ============================================================ */

require __DIR__ . '/auth-common.php';
require __DIR__ . '/db-connect.php';
$conn = getDbConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonFail('Only POST is accepted.', 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    jsonFail('Invalid JSON payload.');
}

$name     = trim((string) ($data['name'] ?? ''));
$email    = trim((string) ($data['email'] ?? ''));
$password = (string) ($data['password'] ?? '');

if ($name === '' || mb_strlen($name) > 150) {
    jsonFail('Please enter your name.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonFail('Please enter a valid email address.');
}
if (mb_strlen($password) < 8) {
    jsonFail('Password must be at least 8 characters.');
}

$email = mb_substr($email, 0, 190);
$hash  = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
$stmt->bind_param('sss', $name, $email, $hash);

try {
    $stmt->execute();
} catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) {
        jsonFail('An account with that email already exists — try signing in instead.', 409);
    }
    error_log('Register failed: ' . $e->getMessage());
    jsonFail('Could not create the account.', 500);
}

$userId = $stmt->insert_id;
$stmt->close();
$conn->close();

startSessionFor(['id' => $userId, 'name' => $name, 'email' => $email]);

echo json_encode(['status' => 'ok', 'user' => ['id' => $userId, 'name' => $name, 'email' => $email]]);
