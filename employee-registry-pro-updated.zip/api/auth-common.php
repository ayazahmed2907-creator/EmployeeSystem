<?php
/* ============================================================
   auth-common.php
   Session bootstrap + helpers shared by every auth-*.php file
   and by every employee-data endpoint (query.php,
   register-employee.php, update-employee.php,
   delete-employee.php). Include this BEFORE db-connect.php.

   >>> Set GOOGLE_CLIENT_ID below once you've created one in the
       Google Cloud Console (see README-LOGIN.md). Until then the
       "Sign in with Google" button will show a clear error;
       email + password login/registration works right away. <<<
   ============================================================ */

define('GOOGLE_CLIENT_ID', 'PUT-YOUR-GOOGLE-CLIENT-ID-HERE.apps.googleusercontent.com');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

header('Content-Type: application/json');

function jsonFail($message, $code = 400) {
    http_response_code($code);
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit;
}

/* Every employee-data endpoint calls this first. Returns the
   logged-in user's id, or stops the request with 401. */
function requireAuth(): int {
    if (empty($_SESSION['user_id'])) {
        jsonFail('Please sign in to continue.', 401);
    }
    return (int) $_SESSION['user_id'];
}

function currentUser(): ?array {
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    return [
        'id'    => (int) $_SESSION['user_id'],
        'name'  => $_SESSION['user_name']  ?? '',
        'email' => $_SESSION['user_email'] ?? '',
    ];
}

function startSessionFor(array $user): void {
    session_regenerate_id(true); // prevent session fixation on login/register
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
}
