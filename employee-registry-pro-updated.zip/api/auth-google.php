<?php
/* ============================================================
   auth-google.php
   Verifies the ID token Google's "Sign in with Google" button
   hands to the browser, then signs the person in (creating an
   account the first time they use Google for this email).

     POST auth-google.php   body: { credential: "<Google ID token>" }

   Requires GOOGLE_CLIENT_ID to be set in auth-common.php — see
   README-LOGIN.md for how to create one. Until it's set, this
   endpoint returns a clear error instead of silently failing.
   ============================================================ */

require __DIR__ . '/auth-common.php';
require __DIR__ . '/db-connect.php';
$conn = getDbConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonFail('Only POST is accepted.', 405);
}

if (GOOGLE_CLIENT_ID === 'PUT-YOUR-GOOGLE-CLIENT-ID-HERE.apps.googleusercontent.com') {
    jsonFail('Google Sign-In is not configured yet on this server. Use email + password for now.', 503);
}

$data = json_decode(file_get_contents('php://input'), true);
$credential = trim((string) ($data['credential'] ?? ''));
if ($credential === '') {
    jsonFail('Missing Google credential.');
}

/* Ask Google itself to verify the token's signature/expiry and hand back
   its claims — simplest possible correct verification, no extra library. */
$verifyUrl = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($credential);
$context   = stream_context_create(['http' => ['timeout' => 8]]);
$response  = @file_get_contents($verifyUrl, false, $context);

if ($response === false) {
    jsonFail('Could not reach Google to verify sign-in. Try again.', 502);
}

$claims = json_decode($response, true);
if (!is_array($claims) || empty($claims['sub']) || empty($claims['email'])) {
    jsonFail('Google sign-in could not be verified.', 401);
}
if (($claims['aud'] ?? '') !== GOOGLE_CLIENT_ID) {
    jsonFail('This sign-in was issued for a different app.', 401);
}
if (empty($claims['email_verified']) || $claims['email_verified'] === 'false') {
    jsonFail('That Google account\'s email is not verified.', 401);
}

$googleId = $claims['sub'];
$email    = mb_substr($claims['email'], 0, 190);
$name     = mb_substr($claims['name'] ?? $email, 0, 150);

/* Match an existing account by google_id first, then by email
   (so someone who registered with email+password can also use
   "Sign in with Google" on the same address afterward). */
$stmt = $conn->prepare('SELECT id, name, email FROM users WHERE google_id = ? OR email = ? LIMIT 1');
$stmt->bind_param('ss', $googleId, $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($user) {
    $update = $conn->prepare('UPDATE users SET google_id = ? WHERE id = ?');
    $update->bind_param('si', $googleId, $user['id']);
    $update->execute();
    $update->close();
} else {
    $insert = $conn->prepare('INSERT INTO users (name, email, google_id) VALUES (?, ?, ?)');
    $insert->bind_param('sss', $name, $email, $googleId);
    try {
        $insert->execute();
    } catch (mysqli_sql_exception $e) {
        error_log('Google register failed: ' . $e->getMessage());
        jsonFail('Could not create the account.', 500);
    }
    $user = ['id' => $insert->insert_id, 'name' => $name, 'email' => $email];
    $insert->close();
}

$conn->close();
startSessionFor($user);

echo json_encode(['status' => 'ok', 'user' => ['id' => (int) $user['id'], 'name' => $user['name'], 'email' => $user['email']]]);
