<?php
/* GET auth-session.php -> { status: ok, user: {...} } or 401 if signed out */
require __DIR__ . '/auth-common.php';

$user = currentUser();
if (!$user) {
    jsonFail('Not signed in.', 401);
}

echo json_encode(['status' => 'ok', 'user' => $user]);
